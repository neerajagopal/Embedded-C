// Embedded Microcontroller
//Neeraja Gopal
//1001119411

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: EK-TM4C123GXL Evaluation Board
// Target uC:       TM4C123GH6PM
// System Clock:    40 MHz

// Hardware configuration:
// Red LED:
//   PF3 drives an NPN transistor that powers the Green LED

//-----------------------------------------------------------------------------
// Device includes, defines, and assembler directives
//-----------------------------------------------------------------------------

#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "tm4c123gh6pm.h"
#include <string.h>
#include <math.h>
#include <ctype.h>

#define GREEN_LED   (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 3*4)))
#define RED_LED     (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 1*4)))
#define BLUE_LED    (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 2*4)))
#define DE          (*((volatile uint32_t *)(0x42000000 + (0x400063FC-0x40000000)*32 + 6*4)))


// Declaring Global Variables
char str[81],char_type[81],type[10];
char* cmd;
uint8_t count,min_Args,checksum;
uint8_t position[10],data_value[10],channel,FL_seq_ID=0,command,size;
int temp,ack,rx_phase=0,tx_phase=0,red_timeout=25,green_timeout=25,retrans_time=0;
uint8_t address,address_new,rx_byte;
uint8_t seq_ID;
uint8_t cmd_rx;
uint8_t ch_rx;
uint8_t size_rx;
uint8_t rx_data_value[10]={0};
uint32_t rx_address,Rx_byte;
uint32_t my_address=2;
int write_index=0,read_index=0,Buf_len=10,re_trans_count=0,max_count=3;
uint8_t checksum_new,master_add=7;
uint8_t checksum_rx;
uint8_t Add[10],S_ID[10],Cmd[10],Ch[10],Size[10],Data[10][10],Check_sum[10],Ack[10],Re_trans[10],Retrans_timeout[10],Valid[10];

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

// Initialize Hardware
void initHw()
{
	// Configure HW to work with 16 MHz XTAL, PLL enabled, system clock of 40 MHz
    SYSCTL_RCC_R = SYSCTL_RCC_XTAL_16MHZ | SYSCTL_RCC_OSCSRC_MAIN | SYSCTL_RCC_USESYSDIV | (4 << SYSCTL_RCC_SYSDIV_S);

    // Set GPIO ports to use APB (not needed since default configuration -- for clarity)
    SYSCTL_GPIOHBCTL_R = 0;

    // Enable GPIO port A and F and C peripherals
    SYSCTL_RCGC2_R = SYSCTL_RCGC2_GPIOA | SYSCTL_RCGC2_GPIOF | SYSCTL_RCGC2_GPIOC;

    // Configure LED and pushbutton pins
    GPIO_PORTF_DIR_R = 0x0E;  // make bit 1,2,3 outputs
    GPIO_PORTF_DR2R_R = 0x0E; // set drive strength to 2mA (not needed since default configuration -- for clarity)
    GPIO_PORTF_DEN_R = 0x0E;  // enable LEDs

    // Configure UART0 pins
   	SYSCTL_RCGCUART_R |= SYSCTL_RCGCUART_R0;         // turn-on UART0, leave other uarts in same status
    GPIO_PORTA_DEN_R |= 3;                           // default, added for clarity
   	GPIO_PORTA_AFSEL_R |= 3;                         // default, added for clarity
    GPIO_PORTA_PCTL_R = GPIO_PCTL_PA1_U0TX | GPIO_PCTL_PA0_U0RX;

    // Configure UART0 to 115200 baud, 8N1 format (must be 3 clocks from clock enable and config writes)
    UART0_CTL_R = 0;                                 // turn-off UART0 to allow safe programming
    UART0_CC_R = UART_CC_CS_SYSCLK;                  // use system clock (40 MHz)
    UART0_IBRD_R =21;                               // r = 40 MHz / (Nx115.2kHz), set floor(r)=65, where N=16
    UART0_FBRD_R =45;                               // round(fract(r)*64)=7
    UART0_LCRH_R = UART_LCRH_WLEN_8 | UART_LCRH_SPS | UART_LCRH_FEN; // configure for 8N1 w/ 16-level FIFO
    UART0_CTL_R = UART_CTL_TXE | UART_CTL_RXE | UART_CTL_UARTEN; // enable TX, RX, and module

    // Configure UART1 pins
    SYSCTL_RCGCUART_R |= SYSCTL_RCGCUART_R1;         // turn-on UART0, leave other uarts in same status
    GPIO_PORTC_DEN_R |= 0x70;                           // default, added for clarity
    GPIO_PORTC_AFSEL_R |= 0x30;                         // default, added for clarity
    GPIO_PORTC_PCTL_R |= GPIO_PCTL_PC5_U1TX | GPIO_PCTL_PC4_U1RX;
    GPIO_PORTC_DR2R_R = 0x40; // set drive strength to 2mA (not needed since default configuration -- for clarity)
    //GPIO_PORTC_DEN_R |= 0x70;  // enable LED
    GPIO_PORTC_DIR_R = 0x40;  // make bit 6 an outputs

    // Configure UART1 to 38400 baud, 8N1 format (must be 3 clocks from clock enable and config writes)
    UART1_CTL_R = 0;                                 // turn-off UART1 to allow safe programming
    UART1_CC_R = UART_CC_CS_SYSCLK;                  // use system clock (40 MHz)
    UART1_IBRD_R =65;                               // r = 40 MHz / (Nx115.2kHz), set floor(r)=65, where N=16
    UART1_FBRD_R =7;                               // round(fract(r)*64)=7
    UART1_LCRH_R = 0xE6; 							// configure for 8N1 w/ FIFO Disabled
    UART1_IM_R = UART_IM_TXIM | UART_IM_RXIM;		// turn-on RX interrupt
    NVIC_EN0_R |= 1 << (INT_UART1-16);               // turn-on interrupt 22 (UART1)
    UART1_CTL_R = UART_CTL_TXE | UART_CTL_RXE | UART_CTL_UARTEN;//| UART_CTL_LBE; // enable TX, RX, and module
   // UART1_DR_R=0x00;

    // Configure Timer 1 as the time base
    SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R1;       // turn-on timer
    TIMER1_CTL_R &= ~TIMER_CTL_TAEN;                 // turn-off timer before reconfiguring
    TIMER1_CFG_R = TIMER_CFG_32_BIT_TIMER;           // configure as 32-bit timer (A+B)
    TIMER1_TAMR_R = TIMER_TAMR_TAMR_PERIOD;          // configure for periodic mode (count down)
    TIMER1_TAILR_R = 0x61A80;                        // set load value to 40e4 for 100 Hz interrupt rate
    TIMER1_IMR_R = TIMER_IMR_TATOIM;                 // turn-on interrupts
    NVIC_EN0_R |= 1 << (INT_TIMER1A-16);             // turn-on interrupt 37 (TIMER1A)
   //TIMER1_CTL_R |= TIMER_CTL_TAEN;                  // turn-on timer

   //Reset
    NVIC_APINT_R=0x05FA0000;
   }


// Approximate busy waiting (in units of microseconds), given a 40 MHz system clock
void waitMicrosecond(uint32_t us)
{
	__asm("WMS_LOOP0:   MOV  R1, #6");          // 1
    __asm("WMS_LOOP1:   SUB  R1, #1");          // 6
    __asm("             CBZ  R1, WMS_DONE1");   // 5+1*3
    __asm("             NOP");                  // 5
    __asm("             NOP");                  // 5
    __asm("             B    WMS_LOOP1");       // 5*2 (speculative, so P=1)
    __asm("WMS_DONE1:   SUB  R0, #1");          // 1
    __asm("             CBZ  R0, WMS_DONE0");   // 1
	__asm("             NOP");                  // 1
    __asm("             B    WMS_LOOP0");       // 1*2 (speculative, so P=1)
    __asm("WMS_DONE0:");                        // ---
                                                // 40 clocks/us + error
}


//UART 0

// Blocking function that writes a serial character when the UART buffer is not full
void putcUart0(char c)
{
	while (UART0_FR_R & UART_FR_TXFF);
	UART0_DR_R = c;
}
//Function that writes a string when the UART buffer is not full
void putsUart0(char* str)
{
	int i;
    for (i = 0; i < strlen(str); i++)
	  putcUart0(str[i]);
}

//Function that returns with serial data
char getcUart0()
{
	while (UART0_FR_R & UART_FR_RXFE);
	return UART0_DR_R & 0xFF;
}

void Timer1Isr()
{
	if((red_timeout!=0) && RED_LED == 1)
		red_timeout--;
	else if((red_timeout==0) && RED_LED==1)
		RED_LED=0;
	else if((green_timeout!=0) && GREEN_LED == 1)
		green_timeout--;
	else if((green_timeout==0) && GREEN_LED==1)
		GREEN_LED=0;

//Retransmission
	/*retrans_time--;
	if(Ack[read_index]==1)
	{
		if(re_trans_count<max_count)
		{
			UART1_DR_R=0x00; // prime the pump
		}
		else
		{
				putsUart0("\r\n Data Lost \r\n");
		}
	}*/
	TIMER1_ICR_R |= TIMER_ICR_TATOCINT;               // clear interrupt flag
}


// UART 1

// Blocking function that writes a number when the UART1 buffer is not full
void putintUart1(uint8_t num)
{
	while(UART1_FR_R & UART_FR_TXFF);
	UART1_DR_R=num;
}

//Function that returns with serial data
char getintUart1()
{
	while (UART1_FR_R & UART_FR_RXFE);
	return UART1_DR_R & 0xFF;
}

//STEP 2
// Function to receive a string
void r_str()
{
	char c;
	count=0;
	while(1)
	{ // Get a character

		c=getcUart0();
		putcUart0(c);

	//Checking for backspace
	if ((c==8)&&(count>0))
	{
		count=count-1;

	}
	//Checking for Carriage return
	if (c==13)
	{
		str[count] ='\0';
		break;
	}
	//checking for values greater than 32 (space)
	if (c>=32)
	{
		str[count]=c;
		count++;
	}
	if (count==81)
	{
		str[count]='\0';
		break;
	}
	}
}

// STEP 3
void parse_str()
{ // checking for delimiters and making them NULL
	int i=0,p;
	int j=0;
	int k=0;
	int n=0;
	temp = 0;
	for(p=0; p<81;p++)
		char_type[p]='0';

	// Assigning Type
	    for (i=0;i<=strlen(str);i++)
	    	{
	    	str[i]=tolower(str[i]);
	    	if ((str[i]>= 'a' && str[i]<= 'z'))
	    		char_type[i]='A';
	    	else if ((str[i]>='0') && (str[i]<='9'))
	    		char_type[i]='N';
	    	else
				char_type[i]='D';
	    	}
	 // Calculating position

	    for (j=0;j<=strlen(char_type);j++)
	    	{
	    	if (((char_type[0]=='A')) && temp == 0)
	    	{
	    		position[0]=0;
	    		type[0]='A';
	    		temp++;
	    	}
	    	if ((char_type[j]=='D') && (char_type[j+1]=='N'))
	    	{
	    		position[temp]=j+1;
	    		type[temp]='N';
	    		temp++;
	    	}
	    	if (char_type[j]=='D' && char_type[j+1]=='A')
	    		{
	    		position[temp]=j+1;
	    		type[temp]='A';
	    		temp++;
	    		}
	    	if (char_type[j]=='N' && char_type[j+1]=='A')
	    	{
	    		position[temp]=j+1;
	    		type[temp]='A';
	    		temp++;
	    	}
	    	if (char_type[j]=='A' && char_type[j+1]=='N')
	        {
	    		 position[temp]=j+1;
	    		 type[temp]='N';
	    		 temp++;
	    	}
	    	}
	    // Code and Discard for STEP 3

	    		while(str[n]!='\0')
	    		{
	    			if(str[n]==' ' | str[n]==',')

	    				str[n]='\0';
	    			n++;

	    		}
	    		putsUart0("\r\n");
	    		//putsUart0(str);
	    		for (k=0;k<temp;k++)
	    			    		{
	    			    			//printf(&str_1[position[k]]);
	    			    			putsUart0("\r\n");
	    			    			putsUart0(&str[position[k]]);
	    			    		}
}

// STEP 4

	// Checking if it's a valid function

	_Bool isCommand(char* cmd, int min_Args)

	{
		int okay;
		okay= strcmp(cmd,&str[position[0]]);
		if ((okay==0) && ((min_Args==(temp-1))))
		return true;
		else
		return false;
	}

//Checking whether data in the field of the given string is a number
// Getting a Value
int getNumber(uint8_t val)
	{
		return(atoi(&str[position[val]]));

	}
 _Bool isNumber(uint8_t I)
	{
		if((char_type[position[I]]=='N') && (getNumber(I)<256))
		{
					return 1;
		}
		else
		{
					return 0;
		}
	}
	// Similarly for alpha field
	_Bool isAlpha(uint8_t J)
	{
		if(char_type[position[J]]=='A')
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

// STEP 5

	void send485(uint32_t address,uint8_t command,uint8_t channel,uint8_t size,uint8_t data_value[])
	{
	//UART1_LCRH_R = UART_LCRH_WLEN_8 | UART_LCRH_PEN | UART_LCRH_SPS; // configure for 8N1 w/ FIFO Disabled
	uint8_t temp_sum;
	uint8_t sum;
	int m,v;
	//red_timeout=25;
	for (v=0;v<Buf_len;v++)
	{
		if (Valid[v]==0)
			write_index=v;
		break;
	}
	Add[write_index]=address;
    S_ID[write_index]=FL_seq_ID;
    if(ack==1)
    {
    	command |= 0x80;
    }
    Cmd[write_index]=command;
    Ch[write_index]=channel;
    Size[write_index]=size;
    for(m=0;m<size;m++)
    	{
    		Data[m][write_index]=data_value[m];
    	}
	temp_sum=(address+FL_seq_ID+command+channel+size);
	//for (m=0;m<size;m++)
			//{
			sum=temp_sum+data_value[0];
			//}
	checksum=~(sum);
	Check_sum[write_index]=checksum;
	Ack[write_index]=ack;
    Valid[write_index]=1;
    write_index=(write_index+1)%Buf_len;
    UART1_DR_R=0x00;
    }

	//OLD STEP 5

	//DE=1;
	//waitMicrosecond(100000);

	//UART1_CTL_R = 0;  //turn off UART1 for safe programming
	//UART1_LCRH_R=0xE2;
	//UART1_CTL_R = UART_CTL_TXE | UART_CTL_RXE | UART_CTL_UARTEN; // enable TX, RX, and module

	//putintUart1(address);
	//waitMicrosecond(1000);

	//UART1_CTL_R = 0;  //turn off UART1 for safe programming
	//UART1_LCRH_R=0xE6;
	//UART1_CTL_R = UART_CTL_TXE | UART_CTL_RXE | UART_CTL_UARTEN; // enable TX, RX, and module

	//putintUart1(FL_seq_ID);
	//waitMicrosecond(1000);
	//putintUart1(command);
	//waitMicrosecond(1000);
	//putintUart1(channel);
	//waitMicrosecond(1000);
	//putintUart1(size);
	//for (m=0;m<size;m++)
	//{
	//putintUart1(data_value[m]);
	//}
	//waitMicrosecond(1000);
	//putintUart1(checksum);
	//waitMicrosecond(1000);
	//FL_seq_ID=FL_seq_ID+1;
	//waitMicrosecond(1);
	//while(!(UART1_FR_R & UART_FR_BUSY))
	//DE=0;
	//}


//STEP 4

void command_function()
{
	int z;
	//FL_seq_ID=0;
	_Bool flag=false;

	if(isCommand("reset",1))
	{
		if(isNumber(1))
		{
			address=getNumber(1);
			flag=true;
			if(flag)
			{
			command=0x7F;
			size=0;
			channel=0;

			for(z=0;z<10;z++)
			{
				data_value[z]=0;

			}
			send485(address,command,channel,size,data_value);
			//putsUart0("\r\nReset Command Received\r\n");
			}
		}
	}
	else if(isCommand("set",3))
	{
		if(isNumber(1))
		{
			address=getNumber(1);

			if(isNumber(2))
			{
				channel=getNumber(2);

				if(isNumber(3))
				{
					for(z=0;z<10;z++)
					{
						data_value[z]=getNumber(3);
					}
						flag=true;
						if(flag)
											{
												command=0x00;
												size=1;
												send485(address,command,channel,size,data_value);
												//putsUart0("\r\nSet Command Received\r\n");
											}
				}
			}
		}


	}

	else if(isCommand("ack",1))
		{
		if(isAlpha(1))
		{
			if(!strcmp(&str[position[1]],"on"))
			{
				flag=true;
				ack=1;
				/*if(flag)
				//{
					address=0;
					command=0x70;
					channel=0;
					size=1;
					for(z=0;z<10;z++)
						{
						  data_value[z]=0;
						}
					send485(address,command,channel,size,data_value);*/
				if(flag)
					putsUart0("\r\nAcknowledgement ON\r\n");
				//}
			}

			else if (!strcmp(&str[position[1]],"off"))
				{
					flag=true;
					ack=0;

					/*if(flag)
					{
						address=0;
						command=0x70;
						channel=0;
						size=1;
						for(z=0;z<10;z++)
									{
										data_value[z]=0;

									}
						send485(address,command,channel,size,data_value);*/
					if(flag)
						putsUart0("\r\nAcknowledgement OFF\r\n");
					//}
				}
		}
		}

	else if(isCommand("poll",0))
	{
		if(min_Args==0)
		{
			flag=true;

			if(flag)
			{
				address=255;
				command=0x78;
				channel=0;
				size=0;
				for(z=0;z<10;z++)
				{
					data_value[z]=0;

				}
				send485(address,command,channel,size,data_value);
				//putsUart0("\r\n Poll Command Received \r\n");
			}
		}
	}
	else if(isCommand("get",2))
	{
		if(isNumber(1))
		{
			address=getNumber(1);

			if(isNumber(2))
			{
				channel=getNumber(2);
				flag=true;
				if(flag)
								{
									command=0x30;
									size=0;
									for(z=0;z<10;z++)
									{
										data_value[z]=0;

									}
									send485(address,command,channel,size,data_value);
									//putsUart0("\r\n Fetch Address Command Received \r\n");
								}
			}}

	}
	else if(isCommand("sa",2))
	{
		if(isNumber(1))
		{
			address=getNumber(1);

			if(isNumber(2))
			{
				address_new=getNumber(2);
				flag=true;
				if(flag)
								{
									command=0x79;
									size=1;
									data_value[0]=address_new;
									send485(address,command,channel,size,data_value);
									//putsUart0("\r\n New Address Set \r\n");
								}
			}}

	}
	if(!flag)
	{
		putsUart0("\r\nInvalid Command\r\n");
	}
}
//Step 8 and 9
void acknowledge(cmd_rx,ch_rx,size_rx,seq_ID)
	{ int m;
	  char *s;
		if ((cmd_rx && 0x80)==1) //Ack ON
		{
			command=cmd_rx;
			channel=ch_rx;
			size=size_rx;
			data_value[0]=seq_ID;
			waitMicrosecond(10000);
			send485(master_add,command,channel,size,data_value);
			FL_seq_ID++;
			putsUart0("\r\n Acknowledgement sent \r\n");
		}
		if(cmd_rx==0x70) //Master Acknowledgement // step 9
		{
			for (m=0;m<Buf_len;m++)
			{
				if(S_ID[m]==rx_data_value[0])
				{
				sprintf(s,"\r\n Response received from: %u",Add[m]);
				}
				else
				putsUart0("\r\n No response received from the Node \r\n");
			}
		}
		if ((cmd_rx==0x30)||(cmd_rx==0xB0)) //Get Value
		{
			command=0x20;
			channel=ch_rx;
			size=size_rx;
			data_value[0]=200;
			waitMicrosecond(10000);
			send485(master_add,command,channel,size,data_value);
			FL_seq_ID++;
			putsUart0("\r\n Data Value sent \r\n");
		}
		if(cmd_rx==0x20) //Master acknowledge for Get
		{
			sprintf(s,"Value received from Node is: %u",rx_data_value[0]);
		}
		if ((cmd_rx==0x78)||(cmd_rx==0xF8)) //Poll
			{
			command=cmd_rx;
			channel=ch_rx;
			size=size_rx;
			data_value[0]=my_address;
			waitMicrosecond(10000);
			send485(master_add,command,channel,size,data_value);
			FL_seq_ID++;
			putsUart0("\r\n Poll - Node Address sent \r\n");
			}
		if (cmd_rx==0x78)   //Master Acknowledge for Poll
		{
			sprintf(s,"Node that responded is: %u",rx_data_value[0]);
		}
		if((cmd_rx==0x79)||(cmd_rx==0xF9)) //Set address
		{
			BLUE_LED=1;
			address=data_value[0];
			putsUart0("\r\nNew Address Set\r\n");

		}
		if ((cmd_rx==0x7F)||(cmd_rx==0xFF)) //Reset
		{
			NVIC_APINT_R |= NVIC_APINT_SYSRESETREQ;
			putsUart0("\r\n System Reset \r\n");
		}
	}
//Step 10
void U1Rx_Isr()
{
//TRANSMISION
 if (UART1_RIS_R & UART_RIS_TXRIS)
 {

	 //UART1_LCRH_R = UART_LCRH_WLEN_8 | UART_LCRH_PEN | UART_LCRH_SPS; // configure for 8N1 w/ FIFO Disabled
	int v,m;
	RED_LED=1;
	//tx_phase=0;
	for (v=0;v<Buf_len;v++)
		{
			if (Valid[v]==1)
				read_index=v;
			break;
		}
	DE=1;
	waitMicrosecond(1);

	if(tx_phase==0) //&& (Valid[read_index==1]) && Ack[read_index]==0) || ((tx_phase==0) && (Valid[read_index==1]) && Ack[read_index]==1))
	{
		UART1_CTL_R=0; //TURN OFF UART1 FOR SAFE PROGRAMMING
		UART1_LCRH_R=0xE2;
		UART1_CTL_R=UART_CTL_TXE|UART_CTL_RXE|UART_CTL_UARTEN;
		//waitMicrosecond(1);

		putintUart1(Add[read_index]);
		tx_phase=1;
		putsUart0("\r\n Address Sent \r\n");

		UART1_CTL_R=0; //TURN OFF UART1 FOR SAFE PROGRAMMING
		UART1_LCRH_R=0xE6;
		UART1_CTL_R=UART_CTL_TXE|UART_CTL_RXE|UART_CTL_UARTEN;
		//waitMicrosecond(1);
	}
	if(tx_phase==1)
	{
		putintUart1(S_ID[read_index]);
		tx_phase=2;
		putsUart0("\r\n Sequence ID Sent \r\n");
		//waitMicrosecond(1);
	}
	if(tx_phase==2)
	{
		putintUart1(Cmd[read_index]);
		tx_phase=3;
		putsUart0("\r\n Command Sent \r\n");
		//waitMicrosecond(1);
	}
	if(tx_phase==3)
	{
		putintUart1(Ch[read_index]);
		tx_phase=4;
		putsUart0("\r\n Channel Sent \r\n");
		//waitMicrosecond(1);
	}
	if(tx_phase==4)
	{
		putintUart1(Size[read_index]);
		tx_phase=5;
		putsUart0("\r\n Size Sent \r\n");
		//waitMicrosecond(1);
	}
	if(tx_phase==5)
	{
		 for(m=0;m<Size[read_index];m++)
		    	{
		    		putintUart1(Data[m][read_index]);
		    	}
		 tx_phase=6;
		 putsUart0("\r\n Data Sent \r\n");
		 //waitMicrosecond(1);
	}
	if(tx_phase==6)
	{
		putintUart1(Check_sum[read_index]);
		tx_phase=0;
		putsUart0("\r\n Check sum Sent \r\n");
		//waitMicrosecond(1);
	}
	FL_seq_ID=FL_seq_ID+1;
	if (Ack[read_index]==0)
	{
		Valid[read_index]=0;
	}
	//read_index=(read_index+1)%Buf_len;


//Retransmission Step 11
	/*if((Ack[read_index]==1) && (Valid[read_index]==1) && (retrans_time==0))
	{
		re_trans_count++;
		retrans_time=100; // 50+50(2^(re_trans_count))
	}*/

	while(UART1_FR_R & UART_FR_BUSY);
	DE=0;

	UART1_ICR_R = UART_ICR_TXIC;                       // clear TX interrupt
}

//RECEIVE
  if (UART1_RIS_R & UART_RIS_RXRIS )
 {
	 GREEN_LED=1;
	 	//int m,g;
	 	uint8_t new_temp;
	 	uint8_t new_sum;
	 	Rx_byte=(UART1_DR_R & 0xFFF); //to get 12 bits
	 	rx_byte=(Rx_byte & 0xFF); //to get just the data bits

	 	switch(rx_phase)
	 	{
	 	case 0:
	 		{
	 			if((Rx_byte & 0xF00)==0x200) // && (!((Rx_byte && 0x800) && (Rx_byte && 0x400) && (rx_byte && 0x100))))
	 					{
	 						if((rx_byte==my_address)||(rx_byte==255))
	 						{
	 							rx_address=rx_byte;
	 							rx_phase=1;
	 							putsUart0("\r\n Address Received \r\n");
	 						}
	 						else
	 						{
	 							putsUart0("\r\n Not my address \r\n");
	 						}
	 					}

	 			break;

	 		}
	 	case 1:
	 		{
	 			seq_ID=rx_byte;
	 			rx_phase=2;
	 			putsUart0("\r\n Sequence ID received \r\n");
	 			break;
	 		}
	 	case 2:
	 		{
	 			cmd_rx=rx_byte;
	 			rx_phase=3;
	 			putsUart0("\r\n Command received \r\n");
	 			break;
	 		}
	 	case 3:
	 		{
	 			ch_rx=rx_byte;
	 			rx_phase=4;
	 			putsUart0("\r\n Channel received \r\n");
	 			break;
	 		}
	 	case 4:
	 		{
	 			size_rx=rx_byte;
	 			rx_phase=5;
	 			putsUart0("\r\n Size received \r\n");
	 			break;
	 		}
	 	case 5:
	 		{
	 			if(size_rx==0)
	 			{
	 			checksum_new=rx_byte;
	 			rx_phase=0;
	 			putsUart0("\r\n Checksum received \r\n");
	 			}
	 			else
	 			{
	 			//for (g=0;g<size;g++)
	 			//{
	 				rx_data_value[0]=rx_byte;
	 			//}
	 			rx_phase=6;
	 			putsUart0("\r\n Data received \r\n");
	 			}
	 			break;
	 		}
	 	case 6:
	 		{
	 			if (size_rx==1)
	 			{
	 			checksum_new=rx_byte;
	 			rx_phase=0;
	 			putsUart0("\r\n Checksum received \r\n");
	 			}

	 			new_temp=(rx_address+seq_ID+cmd_rx+ch_rx+size_rx);
	 					//for (m=0;m<size;m++)
	 							//{
	 							new_sum=new_temp+rx_data_value[0];
	 							//}
	 					checksum_rx=~(new_sum);
	 					if (checksum_rx==checksum_new)
	 					{
	 						putsUart0("\r\n Data Received Properly \r\n");
	 						if(ch_rx==2)
	 							{
	 							if(rx_data_value[0]==1)
	 								BLUE_LED=1;
	 							else if(rx_data_value[0]==0)
	 								BLUE_LED=0;
	 							}
	 						//acknowledge(cmd_rx,ch_rx,size_rx,seq_ID);

	 					}
	 					else
	 						putsUart0("\r\n Checksum Mismatch \r\n");

	 			break;
	 		}

	 	}
	acknowledge(cmd_rx,ch_rx,size_rx,seq_ID);
	while(UART1_FR_R & UART_FR_BUSY);
	UART1_ICR_R = UART_ICR_RXIC;                       // clear RX interrupt
}
}

//-----------------------------------------------------------------------------
// Main
//-----------------------------------------------------------------------------

int main(void)
{
	// Initialize hardware
	initHw();
// Step 1
    // Power ON LED
	GREEN_LED=1;
	waitMicrosecond(500000);
	GREEN_LED=0;
	TIMER1_CTL_R |= TIMER_CTL_TAEN;                  // turn-on timer

// Step 2
	while(1)
	{
    // Get string
	putsUart0("\r\nEnter the Command:\r\n");
    //
	r_str();
    putsUart0("\r\n");
// Step 3
    parse_str();
// Step 4
    command_function();
  	}
}

